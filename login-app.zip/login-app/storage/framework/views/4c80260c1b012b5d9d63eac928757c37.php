<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Laravel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }
        .card {
            background: white;
            padding: 30px;
            border-radius: 12px;
            width: 320px;
            box-shadow: 0 4px 18px #0001;
        }
        input, button {
            box-sizing: border-box;
            width: 100%;
            padding: 12px;
            margin-top: 8px;
            margin-bottom: 14px;
            border-radius: 6px;
        }
        input { border: 1px solid #cbd5e1; }
        button {
            border: 0;
            background: #dc2626;
            color: white;
            cursor: pointer;
        }
        .error { color: #dc2626; font-size: 14px; }
        .success { color: #15803d; }
    </style>
</head>
<body>
    <div class="card">
        <h2>Login</h2>
        <p>Silakan masuk menggunakan akun Anda.</p>

        <?php if(session('success')): ?>
            <p class="success"><?php echo e(session('success')); ?></p>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="error">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><?php echo e($error); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

       <form method="POST" action="<?php echo e(url('/login')); ?>">
    <?php echo csrf_field(); ?>

    <label>Username</label>
    <input
        type="text"
        name="username"
        value="<?php echo e(old('username')); ?>"
        placeholder="Masukkan username"
        autocomplete="username"
        required
        autofocus
    >

    <label>Password</label>
    <input
        type="password"
        name="password"
        placeholder="Masukkan password"
        autocomplete="current-password"
        required
    >

    <button type="submit">Login</button>
</form>
    </div>
</body>
</html><?php /**PATH D:\login_project\login-app\resources\views/auth/login.blade.php ENDPATH**/ ?>